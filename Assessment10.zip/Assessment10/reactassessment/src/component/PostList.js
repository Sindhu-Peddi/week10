import React, { Component } from 'react';
import axios from 'axios';

class PostList extends Component {
  state = {
    data: [],
  };

  componentDidMount() {
    axios.get('https://datausa.io/api/data?drilldowns=Nation&measures=Population')
      .then(res => {
        const data = res.data.data;
        console.log(data); 
        this.setState({ data });
      });
  }

  render() {
    return (
      <table border={"1"}>
        <thead>
          <tr>
            <th>IDNation</th>
            <th>Year</th>
            <th>Population</th>
          </tr>
        </thead>
        <tbody>
          {this.state.data.map(entry => (
            <tr key={entry.IDNation}>
              <td>{entry.Nation}</td>
              <td>{entry.Year}</td>
              <td>{entry.Population}</td>
            </tr>
          ))}
        </tbody>
      </table>
    );
  }
}

export default PostList;
