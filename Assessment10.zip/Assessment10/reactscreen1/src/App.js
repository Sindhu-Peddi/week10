import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src="/images/infi.jpg" className="App-logo" alt="logo" width="500px" height="px" />
        <pre className='hello'>
          <h1><b>LOADING</b><br></br>
            <b>  SCREEN</b><br></br>
            <b>REACTJS</b><br></br></h1>
          <div className="loading-symbol"> 
            ⌛ Loading...
          </div>
        </pre>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}

export default App;
